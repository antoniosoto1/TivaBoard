/****************************************************************************************************/
/**
\file       ssi.h
\brief      Synchronous Serial Interface functions
\author     Antonio Rodriguez
\version    1.0
\date       17/sept/2014
*/
/****************************************************************************************************/

#ifndef __SSI_H        /*prevent duplicated includes*/
#define __SSI_H

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

/** Variable types and common definitions */
  #include    "typedefs.h"
	#include    "ssi_cfg.h"
	
#define DC                      (*((volatile unsigned long *)0x40004100))
#define DC_COMMAND              0
#define DC_DATA                 0x40
#define RESET                   (*((volatile unsigned long *)0x40004200))
#define RESET_LOW               0
#define RESET_HIGH              0x80

#define SSI_RCGC1_SSI0_SHIFT   (4)  // temporally used, it works fine for SSI1/0 but nothing to do with SSI2/3 
#define SYSCTL_RCGC2_GPIOA      0x00000001  // port A Clock Gating Control




/*****************************************************************************************************
* Definition of module wide MACROs / #DEFINE-CONSTANTs 
*****************************************************************************************************/
typedef struct 
{
	UINT8  *		u8SSI_RxData;
	UINT8  *		u8SSI_TxData;
	UINT8  * 		pu8SSI_Receive_Data_ptr;
	UINT8  * 		pu8SSI_Read_Receive_Data_ptr;
	UINT8  *		pu8SSI_Read_Transmit_Data_ptr;
	UINT8  			u8SSI_RxLength;
	UINT8 			u8SSI_TxLength;
  UINT8  			u8SSI_Comm_Status;	
  tSSI_Channel	SSI_channel;
}tSSIchannel_status;

typedef struct 
{      
    tSSIchannel_status *      	SSIchannel_status;
    UINT8                       u8Number_of_SSI_channels;
}tSSIdriver_status;
                         
/** SCI Initialization */

void vfnSSI_Init(tSSIDriver_config *SSI_Dev_Conf);
	
/** SCI Configuration */
/*void vfnSSI_Configure( UINT8  u8SSIPort, UINT32  u32SSIBaudRate, UINT32 u32ChFormat , UINT32 u32ChBL, UINT32 u32frmt, UINT32 u32ssi_frmt, UINT32 u32spi_frmt);*/
void vfnSSI_Configure( UINT8  u8SSIPort, UINT32  u32SSIBaudRate, UINT32 u32ChFormat , UINT32 u32ChBL, UINT32 u32frmt, UINT32 u32ssi_frmt, UINT32 u32spi_frmt, UINT32 u32spi_ch_dvsr );
#endif /* __SSI_H */
