/****************************************************************************************************/
/**
\file       Os_Task.c
\brief      Multi-thread Task scheduler - list of tasks.
\author     Antonio Rodriguez Soto
\version    1.0
\date       /03/2014
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

/** Scheduler function prototypes definitions */
#include    "Os_Types.h"
#include    "Os_TaskM.h"
#include    "Os_Task.h"
#include 		"Nokia_dsp.h"
#include    "SchM.h"
#include    "main.h"

/*Required for CAN*/
#include "io.h"    /*Types declaration*/
#include "can0.h"


 unsigned  char data[4];
/*CAN variables*/
UINT8 XmtData[4];
UINT8 sequenceNum=0; 
//static unsigned long Led;

UINT8 delay_count64ms=0;

/*****************************************************************************************************
* Definition of  VARIABLEs - 
*****************************************************************************************************/

//dword_int counter_RB;
UINT16 task_counters[10]; 
UINT16 max_val= 300;
UINT16 max_val1= 30000; 
UINT16 delay; 
UINT16 delay_cycled_task; 
UINT16 Button1Count;
UINT16 Can0Count;

 StatusType statusOS;


/*****************************************************************************************************
* Definition of module wide (CONST-) CONSTANTs 
*****************************************************************************************************/

/*****************************************************************************************************
* Code of module wide FUNCTIONS
*****************************************************************************************************/



/* List of tasks to be executed @ 2ms */
TASK(SchM_Task_1ms)               
{
   
  task_counters[1]++;
 
  statusOS = TerminateTask() ;

  Dispatcher();
  restore_context();  

	}



/* List of tasks to be executed @ 4ms */
void SchM_Task_4ms(void)
{
//  LEDb_ON(Db1);
  for(delay=0;delay<max_val;delay++){
    ;
  }
  task_counters[2]++;
  
//	LEDb_OFF(Db1);
  statusOS = TerminateTask() ;   
  Dispatcher();
  restore_context();  
	}



/* List of tasks to be executed @ 8ms */
TASK(SchM_Task_8ms)
{
//  LEDb_ON(Db2);
  for(delay=0;delay<max_val;delay++){
   ;
  }
  task_counters[3]++;
 
//	LEDb_OFF(Db2);
  statusOS = TerminateTask() ;   
  Dispatcher();
  restore_context();  
	}


/* List of tasks to be executed @ 16ms */
 TASK(SchM_Task_16ms)
{

//  LEDb_ON(Db3);
  for(delay=0;delay<max_val;delay++){
   ;
  }
  task_counters[4]++;
  
//	LEDb_OFF(Db3);
  statusOS = TerminateTask() ;
   Dispatcher();
  restore_context();     
	}



/* List of tasks to be executed @ 32ms */
TASK(SchM_Task_32ms)
{ 
//  LEDb_ON(Db4); 
     
  for(delay=0;delay<max_val;delay++){
//  _FEED_COP(); 
   
  }
//    LEDb_OFF(Db4);  
  task_counters[5]++;
  statusOS = TerminateTask() ;
  Dispatcher();
  restore_context();  
	}



/* List of tasks to be executed @ 64ms */
TASK(SchM_Task_64ms)
{
//  LEDb_ON(Db5); 

//	delay_count64ms++;
//	if (delay_count64ms==10)  // 10 * 64mS = 640 mS
//	{
//		Nokia5110_Datasent();   //cada 640ms manda dato
//		delay_count64ms =0;
//	}

	
  task_counters[6]++;
  
//	LEDb_OFF(Db5);
   statusOS = TerminateTask() ;
  Dispatcher();
  restore_context();  
	}

	/****************************/
/**** Event driven tasks ****/
/****************************/
TASK(ButtonTask1) 
  {
	UINT8 Led;
   Button1Count++;
	GPIO_PORTF_ICR_R = 0x10;      // acknowledge flag4
  
//	Nokia5110_Clear();
	//Nokia5110_Datasent();
  Nokia5110_SetCursor(0, 1);// MAXY/2 = 24
	Nokia5110_OutString("Es botella  de PET ????    ");
	Led = GPIO_PORTF_DATA_R;   // read previous
	if (Led&0x10)		//SW2 pressed
	{
			Led = 0x04;            // toggle red LED, PF1
	}else if (Led&0x01) // SW1 pressed
	{
			Led = 0x00;            // toggle red LED, PF1
	}	
	GPIO_PORTF_DATA_R=Led;
  statusOS = TerminateTask() ;
  Dispatcher();
  restore_context();
  
  }

	TASK(CAN0_RcvrTASK) 
  {

   Can0Count++;
		RCVData[0] = data[0];
		RCVData[1] = data[1];
		RCVData[2] = data[2];
		RCVData[3] = data[3];
		MailFlag = true;   // new mail
 
  statusOS = TerminateTask() ;
  Dispatcher();
  restore_context();
  
  }
	


	