/****************************************************************************************************/
/**
file       SchM.h
brief      Task scheduler function prototypes
author     Antonio Rodriguez
version    1.0
date       01/03/2014
*/
/****************************************************************************************************/

#ifndef __SCHM_H        /*prevent duplicated includes*/ 
#define    __SCHM_H 

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

/** Core Modules */
/** Configuration Options */
#include    "pit_prt.h"
/** Variable types and common definitions */
#include    "typedefs.h"
/** Scheduler Module type definitions */
#include    "Os_Types.h"
#include    "Gpt_Cfg.h"
//#include    "Os_TaskCfg.h"
#include    "Gpt.h"

#include    "Os_TaskM.h"

//#include    "memory_allocation.h"
/*****************************************************************************************************
* Definition of module wide MACROS / #DEFINE-CONSTANTS 
*****************************************************************************************************/

#define    TASK_SCH_MAX_NUMBER_TIME_TASKS   0x06u
#define    TASK_SCH_MAX_NUMBER_EVENT_TASKS  0x06u  //???



#define    TASK_SCHEDULER_INIT              0x00u
#define    TASK_SCHEDULER_RUNNING           0x01u
#define    TASK_SCHEDULER_OVERLOAD_1MS      0x02u
#define    TASK_SCHEDULER_OVERLOAD_8MS      0x03u
#define    TASK_SCHEDULER_OVERLOAD_32MS     0x04u
#define    TASK_SCHEDULER_HALTED            0xAAu

#define    Channel                          0x00u




/*****************************************************************************************************
* Declaration of module wide FUNCTIONS
*****************************************************************************************************/
/**OS tick callback function.*/

extern void SchM_OsTick(void);

void  restore_context(void);

void Asm_restore_context(void);

void Asm_restore_FirstLevel_context(void);

void Asm_Save_context(void);
void Asm_MovStack(void);

extern void GPIOPortF_HandlerUser(void);


//void  save_context(void);

/** Scheduler Start */
void SchM_Start(void);

/**Backgroud Task*/
void SchM_Background(void);

/**Dispatcher*/
void Dispatcher(void);

#endif // __SCHM_H
