/****************************************************************************************************/
/*
\file       Gpt.h
\brief      (GPT driver) General Purpose Timer driver, Supports PIT reqs.// Table 2-9. Interrupts 					
\author     Antonio Rodriguez Soto,
\date       1/jun/2014
*/   
/****************************************************************************************************/
 
/*****************************************************************************************************
* Include files
*****************************************************************************************************/

/** Own headers */
/* Periodic Interrupt Timer routines prototypes */
#include  "Gpt_Cfg.h"
#include  "pit_prt.h"
/** Variable types and common definitions */
#include  "typedefs.h"
#include 	"inc/tm4c123gh6pm.h"
#include  "Gpt.h"
#include  "main.h"
#include  "Os_Task.h"
#include    "Os_TaskCfg.h"

void (*PeriodicTask)(void);   // user function




/*Inicializa el PIT de acuerdo a la configuracion que se le pasa como parametro*/
 void vfnPIT_init(void(*task)(void), tPITDevice_config *PIT_Dev_Conf)  
  {

    UINT8  i,u8NumOfChannels,interrupt_num;
		UINT32 period;	
    tPIT_Channel channel;
	  tPITchannel_config  *ptrPIT_Ch_Cnf;  //Apuntador a la configuracion de los canales

		PeriodicTask = task;          // user function  
    
		u8NumOfChannels = PIT_Dev_Conf->u8Number_of_PIT_channels;
    if ((u8NumOfChannels)<1) return;  /*Verifica si hay canales a configurar*/


    /* mueve el apuntador de la configuracion a uno local para facilitar la lectura del codigo*/ 	
 	ptrPIT_Ch_Cnf = (tPITchannel_config *)(PIT_Dev_Conf->ptr_PITchannels_config); 
 	/*Configura los canales de acuerdo a la configuracion */	
	
for (i=0;i<u8NumOfChannels;i++)
	{

		period    = (ptrPIT_Ch_Cnf+i)->timerPeriod;
		 
		NVIC_ST_CTRL_R = 0;         // disable SysTick during setup
		NVIC_ST_RELOAD_R = period-1;// reload value
		NVIC_ST_CURRENT_R = 0;      // any write to current clears it
//ANROSO		NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R&0x00FFFFFF)|0x40000000; // priority 2
																// enable SysTick with core clock and interrupts
//ANROSO		NVIC_ST_CTRL_R = 0x07;
	}		
			EnableInterrupts();
		
}
UINT8  ptrCntxLvl;
UINT32 currentSP;
UINT32 Shifted_SP = 0x200004DC;
extern tTaskControlBlock * ptr_task;



/******************************************************************************************************************/
/**
* brief    GPT Initialization
* author  	Antonio Rodriguez
* param    Gpt_ConfigType gpt config - static driver configuration
* return   void
*/  


void Gpt_Init(const Gpt_ConfigType *DrvConfigPtr)
{
     tPITDevice_config * ptr_pit_cnf; 
        /* mueve el apuntador de la configuracion a uno local para facilitar la lectura del codigo*/ 	
     ptr_pit_cnf = (tPITDevice_config *)DrvConfigPtr->ptr_Gpt_Device_Config->ptr_PITDevice_config;    /*Lee la */
    vfnPIT_init(&SchM_OsTick,ptr_pit_cnf);    
}

void Gpt_StartTimer( void) 
{
	NVIC_ST_CTRL_R = 0x07;    					// 10) habilita timer despues de setup;

}


