                                                                                         
/****************************************************************************************************/
/**
\file       Os_task.h
\brief      Tasks to be assigned to each execution thread of Task scheduler.
\author     Antonio Rodriguez
\version    1.0
\date       02/07/2014
*/
/****************************************************************************************************/
#ifndef __OS_TASKS_H
#define __OS_TASKS_H 

 /*****************************************************************************************************
* Include files
*****************************************************************************************************/

/** Variable types and common definitions */
#include    "typedefs.h"


/*****************************************************************************************************
* Definition of module wide VARIABLES
*****************************************************************************************************/

/*****************************************************************************************************
* Declaration of module wide TYPES
*****************************************************************************************************/

/*****************************************************************************************************
* Definition of module wide MACROS / #DEFINE-CONSTANTS 
*****************************************************************************************************/

/*****************************************************************************************************
* Declaration of module wide FUNCTIONS
*****************************************************************************************************/

#ifndef TASK
#define TASK(taskID) void taskID(void)
#endif

#define DeclareTask(taskID) extern TASK(taskID)
	
#define ISR(x) void Os_Entry_##x(void)
	
#define DeclareISR(isr) extern ISR(isr)

/* List of tasks to be executed @ 1ms */
void SchM_Task_1ms( void );
//DeclareTask(SchM_Task_1ms);

/* List of tasks to be executed @ 4ms  */
void SchM_Task_4ms( void );

/* List of tasks to be executed @ 8ms  */
void SchM_Task_8ms( void );

/* List of tasks to be executed @ 16ms */
void SchM_Task_16ms( void );

/* List of tasks to be executed @ 32ms */
void SchM_Task_32ms( void );

/* List of tasks to be executed @ 64ms */
void SchM_Task_64ms( void );

void ButtonTask1(void);

void CAN0_RcvrTASK(void);



#endif /*__OS_TASKS_H */ 

