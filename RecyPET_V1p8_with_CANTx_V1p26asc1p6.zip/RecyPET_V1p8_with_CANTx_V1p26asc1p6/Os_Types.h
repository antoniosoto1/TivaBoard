/****************************************************************************************************/
/**
\file       SchM_Types.h
\brief      Type definitions for Scheduller
\author     Team4   Antonio Soto,  
\version    1.0
\date       25/08/2014
*/
/****************************************************************************************************/

#ifndef __OS_TYPES_H
#define __OS_TYPES_H 


/** Core modules */
/**  Configuration Options */
#include     "Mcu_Cfg.h"

/** Variable types and common definitions */
#include    "typedefs.h"

//#include    "SchM.h"

/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/

typedef UINT16 TaskType;
typedef TaskType * TaskRefType;
typedef UINT8 TaskStateType;
typedef TaskStateType* TaskStateRefType;


/*****************************************************************************************************
* Declaration of module wide TYPES
*****************************************************************************************************/
typedef enum 
{
    SUSPENDED	=0,
    READY			=1,
    RUNNING		=2,
}tTaskStates;

typedef enum 
{
    ACTIVATE_TASK		=0,
    TERMINATE_TASK	=1,
    START_TASK			=2,
}tTaskActions;


typedef enum 
{
		TASKID_0_BCKGRND  =0,  
		TASKID_1_MS				=1,
    TASKID_4_MS				=2,
    TASKID_8_MS				=3,
    TASKID_16_MS			=4,
    TASKID_32_MS			=5,
    TASKID_64_MS			=6,
  /****************************/
  /**** Event driven tasks ****/
  /****************************/
	  Button_Task1_ID		=7,
	
}tSchedulerTasks_ID;

typedef struct  
  {
   UINT16  abs_deadline;
   UINT16  rel_deadline;
  }tDeadline;

	
 typedef struct  
{
 UINT32 * Stack_Start;
 UINT32 * Stack_End;
 UINT32 * Stack_CntxLvl1;
}tStackInformation;


/*
#ifndef TASK
#define TASK(taskID) void taskID(void)
#endif

#define DeclareTask(taskID) extern TASK(taskID)
#endif	
*/

#define FIFOSIZE    9



typedef char DataType;


#define Mask_T1  1
#define Mask_T2  7
#define Mask_T3  15
#define Mask_T4  31
#define Mask_T5  63
#define Mask_T6  127


#define Offset_T1  0
#define Offset_T2  1
#define Offset_T3  3
#define Offset_T4  5
#define Offset_T5  7
#define Offset_T6  11

  /****************************/
  /**** Event driven tasks ****/
  /****************************/
 /* those tasks only have priority, 
    neither offset nor mask*/ 

#define Periodic_Task   0
#define Event_driven_Task 1  

typedef enum 
{
 E_OK         =0 ,
 E_OS_ACCESS  =1 ,
 E_OS_CALLEVEL=2 ,
 E_OS_ID      =3 ,
 E_OS_LIMIT   =4 ,
 E_OS_NOFUNC  =5 ,
 E_OS_RESOURCE=6 ,
 E_OS_STATE   =7 ,
 E_OS_VALUE   =8 ,
}StatusType;

#endif /*__OS_TYPES_H */  
