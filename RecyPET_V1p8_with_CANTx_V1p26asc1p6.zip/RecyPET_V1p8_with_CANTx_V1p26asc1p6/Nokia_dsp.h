/****************************************************************************************************/
/**
\file       Nokia_dsp.h
\brief      Serial Communication Interface functions
\author     Antonio Rodriguez Soto
\version    1.0
\date       24/Sept/2014
*/
/****************************************************************************************************/

#ifndef __NOKIADISP_H        /*prevent duplicated includes*/
#define __NOKIADISP_H

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

/** Variable types and common definitions */

  #include  "ssi.h"
	#include  "ssi_prt.h"

/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/

/*--  Status ----------------------------------------------------------*/
#define SSI_SR_BSY          0x00000010  // SSI Busy Bit
#define SSI_SR_TNF          0x00000002  // SSI Transmit FIFO Not Full e.g. while((SSI0_SR_R&SSI_SR_TNF)==0){}; // wait until transmit FIFO not full

static unsigned short count = 0;
	
/*******************************************************************************************************************
* Code of module wide FUNCTIONS
*******************************************************************************************************************/

//********Nokia5110_Init*****************
// Initialize Nokia disp 48x84 LCD by sending the proper
// commands to the PCD8544 driver.  One new feature of the
// LM4F120 is that its SSIs can get their baud clock from
// either the system clock or from the 16 MHz precision
// internal oscillator.  If the system clock is faster than
// 50 MHz, the SSI baud clock will be faster than the 4 MHz
// maximum of the Nokia disp.
// inputs: none
// outputs: none
// assumes: system clock rate of 50 MHz or less
void Nokia5110_Init(void);

//********Nokia5110_OutChar*****************
// Print a character to the Nokia disp 48x84 LCD.  The
// character will be printed at the current cursor position,
// the cursor will automatically be updated, and it will
// wrap to the next row or back to the top if necessary.
// One blank column of pixels will be printed on either side
// of the character for readability.  Since characters are 8
// pixels tall and 5 pixels wide, 12 characters fit per row,
// and there are six rows.
// inputs: data  character to print
// outputs: none
// assumes: LCD is in default horizontal addressing mode (V = 0)
void Nokia5110_OutChar(unsigned char data);

//********Nokia5110_OutString*****************
// Print a string of characters to the Nokia 5110 48x84 LCD.
// The string will automatically wrap, so padding spaces may
// be needed to make the output look optimal.
// inputs: ptr  pointer to NULL-terminated ASCII string
// outputs: none
// assumes: LCD is in default horizontal addressing mode (V = 0)
void Nokia5110_OutString(char *ptr);

//********Nokia5110_OutUDec*****************
// Output a 16-bit number in unsigned decimal format with a
// fixed size of five right-justified digits of output.
// Inputs: n  16-bit unsigned number
// Outputs: none
// assumes: LCD is in default horizontal addressing mode (V = 0)
void Nokia5110_OutUDec(unsigned short n);

//********Nokia5110_SetCursor*****************
// Move the cursor to the desired X- and Y-position.  The
// next character will be printed here.  X=0 is the leftmost
// column.  Y=0 is the top row.
// inputs: newX  new X-position of the cursor (0<=newX<=11)
//         newY  new Y-position of the cursor (0<=newY<=5)
// outputs: none
void Nokia5110_SetCursor(unsigned char newX, unsigned char newY);

//********Nokia5110_Clear*****************
// Clear the LCD by writing zeros to the entire screen and
// reset the cursor to (0,0) (top left corner of screen).
// inputs: none
// outputs: none
void Nokia5110_Clear(void);

//********Nokia5110_DrawFullImage*****************
// Fill the whole screen by drawing a 48x84 bitmap image.
// inputs: ptr  pointer to 504 byte bitmap
// outputs: none
// assumes: LCD is in default horizontal addressing mode (V = 0)
void Nokia5110_DrawFullImage(const char *ptr);


void Nokia5110_Datasent(void);

// September 17, 2014
/**************************************************************************************************/


#endif /* __NOKIADISP_H */

