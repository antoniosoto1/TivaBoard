/****************************************************************************************************/
/**
file       main.h
brief      Configuracion de la aplciacion 
author     Luis Puebla, Antonio Soto, Jaime Paz
version    1.0
date       10/Feb/2014
*/
/****************************************************************************************************/

#ifndef __MAIN_H        /*prevent duplicated includes*/
#define __MAIN_H

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

#include "Gpt.h"
#include "Mcu.h"      /* derivative-specific definitions */
#include "SchM.h"

/*******************/
/* Following PIT spec (page 672) time-out period = (PITMTLD + 1) * (PITLD + 1) / fBUS.  */
/* e.g. If Fbus=48MHz,PITLD+1=500,PITMTLD+1=48  500*48/48e6 = 500us, required by lab description */
/*******************/

//#define TIC_OS_PERIOD         5000000-1      // PITLD   Configured to 500us to reach 1ms task


extern void vfnPIT_100ms_callback(void);
extern void vfnPIT_200ms_callback(void);
void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
void WaitForInterrupt(void);  // low power mode

#endif /* __MAIN_H */
