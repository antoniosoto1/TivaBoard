/****************************************************************************************************/
/**
\file       Nokia_test.c
\brief      Serial Communication Interface functions
\author     Antonio Rodriguez Soto
\version    1.0
\date       24/Sept/2014
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/
	#include "typedefs.h"
  #include "Nokia_dsp.h"
	#include "Nokia_test.h"


void vfnSync_Serial_Init(void)
{
	vfnSSI_Init((tSSIDriver_config*)&SSI_app_Configuration);  
}

void Nokia5110_Datasent(void)
{
    Nokia5110_SetCursor(5, 5);          // five leading spaces, bottom row
    Nokia5110_OutChar((count%26)+'A');
    Nokia5110_OutChar(' ');
    Nokia5110_OutUDec(count);
    count = count + 1;
}
