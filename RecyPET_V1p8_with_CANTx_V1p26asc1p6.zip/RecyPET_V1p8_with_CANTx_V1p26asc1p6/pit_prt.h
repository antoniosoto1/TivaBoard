/*
  timers register map pag 723 Table 11-12
  file: pit_ptr.h
  Este archivo complementa las definiciones de perifericos del tm4c123gh6pm.h.
  Define estructuras y macros para acceso a registros a traves de apuntadores 
  lo que facilita la configuracion dinamica de los perifericos.
  Nota:  Estas definiciones estan basdas en la forma en que se manejan los header files en  ARM, por ejemplo MKL46Z4.h de Kinetis
*/




#ifndef __PIT_PRT_H__ 
#define __PIT_PRT_H__


#include "typedefs.h"
#include 	"inc/tm4c123gh6pm.h"

/** PIT - Peripheral register structure for TIMER A */
typedef struct  PIT_MemMap
{
  struct
  {
 	
		UINT32    PIT_CFG;   /* GPTM Configuartion, selects  the #-of bit timer config  	*/	
		UINT32    PIT_TAMR;  /* Timer alternate mode select, Capture or PWM mode. Individual timer A mode */
		UINT32    PIT_TBMR;   
		UINT32    PIT_CTL;   /* En-Dis Timer A, when enabled it begins counting  */
		UINT32    PIT_SYNC;  

		
  }CHANNEL[6];  /* PIT channel[x] timer count*/
}volatile * PIT_MemMapPtr;

typedef struct  PIT_MemMap2
{
  struct
  {
		UINT32    PIT_IMR;   /* GPTM interrupt mask */
		UINT32    PIT_RIS;  
		UINT32    PIT_MIS;  
  }CHANNEL[6];  /* PIT channel[x] timer count*/
}volatile * PIT_MemMapPtr2;

typedef struct  PIT_MemMap3
{
  struct
  {
		UINT32    PIT_ICR ;  /* GPTM interrupt flag clear*/		
		UINT32    PIT_TAILR; /* GPTM timer A interval load. Loads starting counter value into timer*/
		UINT32    PIT_TBILR;  
		UINT32    PIT_TAMATCHR;  
		UINT32    PIT_TBMATCHR;  
		UINT32    PIT_TAPR;  /* GPTM timer A prescale */ 
  }CHANNEL[6];  /* PIT channel[x] timer count*/
}volatile * PIT_MemMapPtr3;

/* PIT - Register accessors */
#define PIT_PITCFG_REG(base,index)                 ((base)->CHANNEL[index].PIT_CFG)
#define PIT_PITTAMR_REG(base,index)                ((base)->CHANNEL[index].PIT_TAMR)
#define PIT_PITTBMR_REG(base,index)                ((base)->CHANNEL[index].PIT_TBMR)
#define PIT_PITCTL_REG(base,index)                 ((base)->CHANNEL[index].PIT_CTL)
#define PIT_PITSYNC_REG(base,index)                ((base)->CHANNEL[index].PIT_SYNC)
#define PIT_PITIMR_REG(base,index)                 ((base)->CHANNEL[index].PIT_IMR)
#define PIT_PITRIS_REG(base,index)                 ((base)->CHANNEL[index].PIT_RIS)
#define PIT_PITMIS_REG(base,index)                 ((base)->CHANNEL[index].PIT_MIS)
#define PIT_PITICR_REG(base,index)                 ((base)->CHANNEL[index].PIT_ICR)
#define PIT_PITTAILR_REG(base,index)               ((base)->CHANNEL[index].PIT_TAILR)
#define PIT_PITTBILR_REG(base,index)               ((base)->CHANNEL[index].PIT_TBILR)
#define PIT_PITTAMATCHR_REG(base,index)            ((base)->CHANNEL[index].PIT_TAMATCHR)
#define PIT_PITTBMATCHR_REG(base,index)            ((base)->CHANNEL[index].PIT_TBMATCHR)
#define PIT_PITTAPR_REG(base,index)                ((base)->CHANNEL[index].PIT_TAPR)


/* ----------------------------------------------------------------------------
   -- PIT Register Masks
   ---------------------------------------------------------------------------- */
/*Estas mascaras estan ya definidas en el header del micro                      */

/* PIT - Peripheral instance base addresses */
/** Peripheral PIT base pointer */
#define PIT_BASE_PTR            ((PIT_MemMapPtr) 0x40030000)
#define PIT_BASE_PTR2            ((PIT_MemMapPtr2) 0x40030018)

#define PIT_BASE_PTR3            ((PIT_MemMapPtr3) 0x40030024)

/* PIT - Register array accessors */
#define PIT_PITCFG(index) 			PIT_PITCFG_REG(PIT_BASE_PTR,index)                 
#define PIT_PITTAMR(index)			PIT_PITTAMR_REG(PIT_BASE_PTR,index) 
#define PIT_PITTBMR(base)       PIT_PITTBMR_REG(PIT_BASE_PTR,index)
#define PIT_PITCTL(index)		  	PIT_PITCTL_REG(PIT_BASE_PTR,index)                
#define PIT_PITSYNC(index)      PIT_PITSYNC_REG(PIT_BASE_PTR,index)
#define PIT_PITIMR(index)			  PIT_PITIMR_REG(PIT_BASE_PTR2,index)                 
#define PIT_PITRIS(index)  			PIT_PITRIS_REG(PIT_BASE_PTR2,index)
#define PIT_PITMIS(index)    		PIT_PITMIS_REG(PIT_BASE_PTR2,index
#define PIT_PITICR(index)			  PIT_PITICR_REG(PIT_BASE_PTR3,index)                
#define PIT_PITTAILR(index)		  PIT_PITTAILR_REG(PIT_BASE_PTR3,index)         
#define PIT_PITTBILR(index) 		PIT_PITTBILR_REG(PIT_BASE_PTR3,index)
#define PIT_PITTAMATCHR(index)  PIT_PITTAMATCHR_REG(PIT_BASE_PTR3,index)
#define PIT_PITTBMATCHR(index)  PIT_PITTBMATCHR_REG(PIT_BASE_PTR3,index)
#define PIT_PITTAPR(index)			PIT_PITTAPR_REG(PIT_BASE_PTR3,index)                


#endif // __PIT_PRT_H__ 
