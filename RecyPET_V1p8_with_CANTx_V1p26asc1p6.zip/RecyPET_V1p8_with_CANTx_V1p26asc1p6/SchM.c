/****************************************************************************************************/
/**
file       SchM.c
brief      Multi-thread Task scheduler.
author     Antonio Rodriguez
version    1.0
date       05/06/2014
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/
/** Scheduler function prototypes definitions */
#include    "SchM.h"
#include    "io.h"
#include    "Os_TaskM.h"
#include    "Os_TaskCfg.h"
#include    "main.h"
#include 		"can0.h"

/*****************************************************************************************************
* Definition of  VARIABLEs - 
*****************************************************************************************************/

UINT16 scheduler_tick_counter;
UINT8 gu8Scheduler_Status;



UINT8 last_priority=0;

UINT32 RcvCount=0;



UINT16 backgroundCount;
extern UINT16 task_counters[10]; 


tTaskControlBlock * ptr_task;

tPtr_to_function            ptrTasktemp;  



/***************************************************************************************************/
/**
* brief    Periodic callback function to be called by the main timer ISR       
            This interrupt is the core of the task scheduler.                   
            It is executed every 500us                                          
            It defines 3 basic threads from which other 3 threads are derived:  
            a) 1ms  thread (basic)->  4ms thread (derived)                      
            b) 8ms  thread (basic)-> 16ms thread (derived)                      
            c) 32ms thread (basic)-> 64ms thread (derived)                      
            It partitions core execution time into time slices (500us each one). 
            This arrangement assures core will have equal task loading across time.   
            For more information on how time slice is assigned to each thread,  
            refer to file "S12X Task Scheduler Layout.xls"
* author   Team4
* param    void
* return   void
* todo
*/



/*Application functions */

void SchM_OsTick(void)
{
	ptr_task = ptr_task_ctrl_block+RunningTaskIndex;

  scheduler_tick_counter++ ;
  Task_sch_activate(&Task_config[0]);
	 
	Dispatcher();
	
	restore_context();
}
 
 
 /* 
  Esta funcion es llamada por el TIC_OS
  Define cual tarea se va a ejecutar dependiendo de la Mascara y el offset.
  
  Usa
       Task_config[]
 
*/
void Task_sch_activate( const tTask_config   *pTask_Config)
{
  
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /*  execution thread - used to derive any execution threads:                */
    /*  As any other thread on this scheduling scheme,                              */
    /*  all tasks must be executed in <= 500us                                      */
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        /* contiene el numero de tareas */
    tSchM_Task_Descriptor *ptr_SchM_TaskConfig;
    StatusType statusOS;
    UINT8 i, task_sch_mask, task_sch_offset,  u8NumOfSchTasks;    
    UINT16 taskID;
        
    u8NumOfSchTasks = pTask_Config->u8Number_of_tasks;
    
   
    ptr_SchM_TaskConfig =(tSchM_Task_Descriptor * )(pTask_Config->ptr_task_config);
    
/*Check si pone el task en ready */
  	for (i=0;i<u8NumOfSchTasks;i++)
	  {

     /* Task Mask */
      task_sch_mask   = (ptr_SchM_TaskConfig+i)->Task_Mask;        
      task_sch_offset = (ptr_SchM_TaskConfig+i)->Task_Offset;
      taskID     = (UINT16 )(ptr_SchM_TaskConfig+i)->task_ID;

      /* Checa si es tarea de tipo periodica*/
      if ((ptr_SchM_TaskConfig+i)->task_type == Periodic_Task)
      {			
				if(((scheduler_tick_counter - task_sch_offset - 1) & task_sch_mask) == task_sch_mask )
				{
					/* Indicate that Task is Ready to be executed */ 
      
        statusOS=ActivateTask(taskID);
      }
	  }
}
}


UINT32 *newSP;
UINT32 *EndSP;
UINT32 *CntxtLvl;
//tPtr_to_function FrstLvl_Task;

void  restore_context(void)
  {        
		newSP = ptr_task->GenTaskInfo.StackInfo.Stack_Start;
		EndSP = ptr_task->GenTaskInfo.StackInfo.Stack_End; 

		
		if( ptr_task->GenTaskInfo.ContextLevel ==0)
		{			
			Asm_restore_context();
		
			ptr_task ->GenTaskInfo.ContextLevel=0;

		}
   else 
	 { 
			 //Hay context y lo va arecuperar

			ptr_task ->GenTaskInfo.ContextLevel--;
			CntxtLvl = ptr_task->GenTaskInfo.StackInfo.Stack_CntxLvl1;
//		 	FrstLvl_Task = ptr_task->GenTaskInfo.ptrSchM_Ostick;
			Asm_restore_FirstLevel_context();
	 }
	 
  }           


void SchM_Start( void  )
 {
 
   /* Update Scheduler Status Running */
   gu8Scheduler_Status = TASK_SCHEDULER_RUNNING;
    (void)ActivateTask(TASKID_0_BCKGRND);
	  
    Dispatcher();
	 /* Perform Low level PIT start */
		Gpt_StartTimer();//Aqui debe ir GPT start que no se tiene en pratica1
  
    restore_context(); 
	 
	 // Code Should never get following instructions
   while(1) 
   {// p13
		  WaitForInterrupt();
   } 
  
 }

  /***************************************************************************************************/
/*  Checa si hay alguna tarea pendiente por ejecutar en la cola de ejecucion
  empieza por las de prioridad mas alta y va recorriendo hasta que acaba todas
   Siempre que se manda llamar al Dispatcher empieza por las prioridades mas altas
  Saca las tares de mas prioridad primero   
* \author   Team4
* \param    void
* \return   StatusType
* \todo     
*/    

 
void Dispatcher(void)
 {
 
   INT16 i;
   UINT16 NewTaskFlag=255;
   tTaskControlBlock * loc_ptr_task;
   loc_ptr_task = ptr_task_ctrl_block+RunningTaskIndex;
   
   i=Task_Number;
   while (i >= (loc_ptr_task->GenTaskInfo.priority) && NewTaskFlag==255)    //es de mayor de prioridad
    { 
      if (priority_buffer[i].data_count>0) /*&& (last_priority<=loc_ptr_task->priority))  //y hay algo por hacer  */
         {       
           //Actualiza el Runnning Task Index
            DisableInterrupts(); 
             RunningTaskIndex = priority_buffer[i].buffer[priority_buffer[i].pull_index];
             ptr_task = ptr_task_ctrl_block+RunningTaskIndex;
             ptr_task->GenTaskInfo.enTaskState = RUNNING;
             NewTaskFlag = RunningTaskIndex; // Bandera para salir del loop
             last_priority=i;
						EnableInterrupts();
             
                       } 
       else  i--; 
     }
       
 }
 
 UINT8 RcvData[4];
 
 /* Background tasks related to Subsystem control */
void SchM_Background(void) 
{
	UINT8 Led;
	task_counters[0]++;
	
	while(1) 
 {
//	    if(CAN0_GetMailNonBlock(RcvData)){
//      RcvCount++;
//      PF1 = RcvData[0];
//      PF2 = RcvData[1];
//      PF3 = RcvCount;   // heartbeat
//	}
			backgroundCount++;
	Led = GPIO_PORTF_DATA_R;   // read previous
	Led = Led^0x08;            // toggle red LED, PF1
	GPIO_PORTF_DATA_R=Led;
	}
}  
