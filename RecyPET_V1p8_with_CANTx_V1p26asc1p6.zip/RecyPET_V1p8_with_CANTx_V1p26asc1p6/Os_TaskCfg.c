      /****************************************************************************************************/
/**
\file       PIT_cnf.h
\brief      PIT Communication Interface functions
\author     Antonio Rodriguez Soto
\version    1.0
\date       2/julio/2014
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

 #include    "Os_TaskCfg.h"  
 #include    "main.h"
 #include    "Os_Types.h"
 
 /*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/
#define StackSizeTask0      100
#define RelativeDeadLine0   0
#define Priority_task0      0    // maxima prioridad = PRIORITY_NUMBER-1
 
#define StackSizeTask1      100
#define RelativeDeadLine1   50
#define Priority_task1_6      6    // maxima prioridad = PRIORITY_NUMBER-1
         
#define StackSizeTask2      100
#define RelativeDeadLine2   50
#define Priority_task2_5      5

#define StackSizeTask3      100
#define RelativeDeadLine3   50
#define Priority_task3_4      4

#define StackSizeTask4      100
#define RelativeDeadLine4   50
#define Priority_task4_3      3

#define StackSizeTask5      100
#define RelativeDeadLine5   50
#define Priority_task5_2      2

#define StackSizeTask6      100
#define RelativeDeadLine6   50
#define Priority_task6_1      1

  /****************************/
  /**** Event driven tasks ****/
  /****************************/

#define StackSizeTask9      100
#define RelativeDeadLine9   50
#define Priority_task9      7

#define StackSizeTask10      100
#define RelativeDeadLine10   50
#define Priority_task10_8      8

/*configura cuales son las tareas que se van a realizar por el scheduler */  

const tSchM_Task_Descriptor  SchM_Config []= 
{
  
  TASKID_0_BCKGRND,
	Event_driven_Task,
  Priority_task0,  
  0, 
  0, 
  StackSizeTask0,
  RelativeDeadLine0,
  SchM_Background,
	
	TASKID_1_MS,
	Periodic_Task,
  Priority_task1_6,  
  Mask_T1, 
  Offset_T1, 
  StackSizeTask1,
  RelativeDeadLine1,
  SchM_Task_1ms,
  
  TASKID_4_MS,
	Periodic_Task,
  Priority_task2_5,  
  Mask_T2, 
  Offset_T2,
  StackSizeTask2,
  RelativeDeadLine2, 
  SchM_Task_4ms,
  
  TASKID_8_MS,
	Periodic_Task,
  Priority_task3_4,  
  Mask_T3, 
  Offset_T3,
  StackSizeTask3,
  RelativeDeadLine3, 
  SchM_Task_8ms,
  
  TASKID_16_MS,
	Periodic_Task,
  Priority_task4_3,  
  Mask_T4, 
  Offset_T4,
  StackSizeTask4,
  RelativeDeadLine4, 
  SchM_Task_16ms,
  
  TASKID_32_MS,
	Periodic_Task,
  Priority_task5_2,  
  Mask_T5, 
  Offset_T5, 
  StackSizeTask5,
  RelativeDeadLine5,
  SchM_Task_32ms,
  
  TASKID_64_MS,
	Periodic_Task,
  Priority_task6_1,  
  Mask_T6, 
  Offset_T6, 
  StackSizeTask6,
  RelativeDeadLine6,
  SchM_Task_64ms,
	
	Button_Task1_ID,             
  Event_driven_Task,           
  Priority_task9,
  0,            //Mascara no aplica para event driven
  0,            //Offset no aplica para event driven                                        
  StackSizeTask9,              
  RelativeDeadLine9,           
  ButtonTask1,                 
 

};
 const tTask_config  Task_config[]=
  {
    sizeof (SchM_Config)/sizeof(SchM_Config[0]), //Numero de tareas para configurar
    &SchM_Config[0]
  };



