/****************************************************************************************************/
/**
file       io.h
brief      Microcontroller low-level input/output initialization functions and prototypes
author     Antonio Rodriguez
version    1.0
date       28/Jun/2014
*/
/****************************************************************************************************/

#ifndef __IO_H        /*prevent duplicated includes*/
#define __IO_H


/*****************************************************************************************************
* Include files
*****************************************************************************************************/
/** Core modules */
/** Omicron Configuration Options */
#include    "Mcu_Cfg.h"

/** Variable types and common definitions */
#include    "typedefs.h"

/** Registros del micro direccionados por el archivo del compilador */
#include 	"inc/tm4c123gh6pm.h"

/** Used modules */

/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/

/*****************************************************************************************************
* Definition of module wide MACROs / #DEFINE-CONSTANTs 
*****************************************************************************************************/

/* Data Direction Register definitions */
#define INPUT           0
#define OUTPUT          1
#define ANALOG_INPUT    2

/* Input pull-up and pull-down definitions */
#define PULL_DOWN       0
#define PULL_UP         1

/* Data output register definition */
#define LOW             0
#define HIGH            1


/** Ports redefinition for macros usability */


/** Status of available push buttons on DEMOS12XEP100 */
#define PP0_push_button         PTIP_PTIP0
#define PP1_push_button         PTIP_PTIP1

#define PUSH_BUTTON_ACTIVE      0u
#define PUSH_BUTTON_INACTIVE    1u

    /************* Digital Inputs Initialization ******************************/
    /* - Configuration of Data Direction Register to Input                    */
    /* - ENABLED Pull up/down option                                           */
    /* - Set pull/down option to specified value                              */
    /**************************************************************************/  

//    #define GPIO_PORTE_IN           (*((volatile unsigned long *)0x4002401C)) // bits 2-0 tm4c123gh6pm.pdf page.652
//    #define SENSOR                  (*((volatile unsigned long *)0x4002401C))

    /************* Digital Outputs Initialization *****************************/
    /* - Configuration of Data Direction Register to Output                   */
    /* - Set pin to specified value                                           */
    /**************************************************************************/
//    #define PortB_TasksLeds            (*((volatile unsigned long *)0x400053FC))
//    #define GPIO_PORTB_OUT             (*((volatile unsigned long *)0x400053FC)) // bits 7-0

//    #define PortF_TasksLeds            (*((volatile unsigned long *)0x400253FC))
//    #define GPIO_PORTF_OUT             (*((volatile unsigned long *)0x400253FC)) // bits 7-0

	#define PF0       (*((volatile UINT32 *)0x40025004))
	#define PF1       (*((volatile UINT32 *)0x40025008))
	#define PF2       (*((volatile UINT32 *)0x40025010))
	#define PF3       (*((volatile UINT32 *)0x40025020))
	#define PF4       (*((volatile UINT32 *)0x40025040))
		
	#define LEDS      (*((volatile unsigned long *)0x40025038))
	#define RED       0x02
	#define BLUE      0x04
	#define GREEN     0x08
	#define WHEELSIZE 8  // have to be an integer multiple of 2
                              //    rojo, amarilla,    verde, light azul, azul, purpura,   clanco,          apagado
//	#define SYSCTL_RCGC2_R          (*((volatile unsigned long *)0x400FE108))
//	#define SYSCTL_RCGC2_GPIOF      0x00000020  // port F Clock Gating Control

#define THENPERCENT_DC   8000
#define NINETYPERCENT_DC 72000
#define FIFTYPERCENT_DC  40000
	
/*****************************************************************************************************
* Declaration of module wide FUNCTIONS
*****************************************************************************************************/

/** Inputs and Outputs Initialization to default values/configuration */
void vfnInputs_Outputs_Init(void);


void ADC0_Init(void);
/**************************************************************************************************/

#endif /* __IO_H */
	
	
