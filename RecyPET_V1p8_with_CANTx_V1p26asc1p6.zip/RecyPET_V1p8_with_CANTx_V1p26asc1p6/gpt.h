/****************************************************************************************************/
/*
\file       Gpt.h
\brief      (GPT driver) General Purpose Timer driver, Supports PIT reqs. 					
\author     Antonio Rodriguez Soto,
\date       1/jun/2014
*/
/****************************************************************************************************/


#ifndef __GPT_H__// do not include more than once
#define __GPT_H__

#include "mcu.h"
#include "Gpt_Cfg.h"


typedef            unsigned         char Gpt_ChannelType ;

/*Inicializacion general de todos los timers*/
void Gpt_Init(const Gpt_ConfigType *DrvConfigPtr);  // Timer0A
void Gpt_StartTimer( void);
void Gpt_StopTimer( Gpt_ChannelType );

void vfnPIT_init(void(*task)(void), tPITDevice_config *PIT_Dev_Conf);
void SchM_OsTick(void);

#endif // __GPT_H__
