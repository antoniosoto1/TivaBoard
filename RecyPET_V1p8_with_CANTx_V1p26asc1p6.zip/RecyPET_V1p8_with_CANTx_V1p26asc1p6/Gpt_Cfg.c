/****************************************************************************************************/
/**
\file       PIT_cnf.h
\brief      PIT Communication Interface functions
\author     Luis Puebla, Antonio Soto, Jaime Paz
\version    1.0
\date       10/Feb/2014
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/


 #include    "Gpt_Cfg.h"
 #include    "main.h"
 #include    "SchM.h"
 
/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/


/*
  Define la configuracion de los Canales del PIT 
   En este caso se usa un canal para el OSTIC
   y otro canal para interrumpir cada 100msec solo de prueba  
   Nota: los canales se puedes escoger al gusto entre 0 y 7   
*/
const tPITchannel_config  PITchannel_config[]=
  {
   PIT_CH_Tim0A,             //PIT channel
   TIC_OS_PERIOD,       // periodo en unidades del MCU 
	 Interrupt_num0,	
   SchM_OsTick,           //Callback Ostick

		/*
   PIT_CH1,                            //PIT channel
   PIT_100MS_PERIOD,                        // periodo en unidades del MCU
   PIT_100MS_MICROTIMER,                    // Va a usar el microtimer1 como base
   vfnPIT_100ms_callback,         //  CallBack function para este canal
   
   PIT_CH2,                            //PIT channel
   PIT_200MS_PERIOD,                        // periodo en unidades del MCU
   PIT_200MS_MICROTIMER,                    // Va a usar el microtimer1 como base
   vfnPIT_200ms_callback,         //  CallBack function para este canal
  */
		};
  
/*
  Define la configuracion del Modulo del PIT
  define las bases de tiempo para los microtimers
  y un apuntador a la configuracion de los canales del PIT	
*/  
const tPITDevice_config  PITDevice_config[]=
  {
    sizeof (PITchannel_config)/sizeof(PITchannel_config[0]), //Numero de PIT channels para configurar
    &PITchannel_config[0]    
  };

  
/*
   Define la configuracion del Modulo del TIM
     place holder 
 */   
const tTIMDevice_config  TIMDevice_config[]=
  {
   0
  };
  
  
/*
  Apunta a la configuracion de PIT y de TIM
  En este caso solo hay una configuracion
*/  
const Gpt_Device_ConfigType  GPT_Device_config[]=
{
  &PITDevice_config[0],
  &TIMDevice_config[0]
};

/* Configuracion general de los timers */

const  Gpt_ConfigType   GPT_Driver_config[]=
  {
   1,                     // Hay un solo una configuracion 
   &GPT_Device_config[0], // Apunta a las Configuracion de Devices (PIT y TIM)
  };
