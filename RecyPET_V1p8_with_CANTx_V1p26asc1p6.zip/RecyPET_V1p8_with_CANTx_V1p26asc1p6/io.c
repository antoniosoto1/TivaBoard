/****************************************************************************************************/
/**
file       io.c
brief      Microcontroller low-level input/output initialization functions
author     Antonio Rodriguez
version    1.0
date       29/Jun/2014
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/
/** Own headers */
/* Input/Output routines prototypes */
#include    "io.h"

/*****************************************************************************************************
* Definition of module wide VARIABLEs 
*****************************************************************************************************/

/****************************************************************************************************
* Declaration of module wide FUNCTIONs 
****************************************************************************************************/

/****************************************************************************************************
* Definition of module wide MACROs / #DEFINE-CONSTANTs 
*****************************************************************************************************/


/****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/

/****************************************************************************************************
* Definition of module wide (CONST-) CONSTANTs 
*****************************************************************************************************/

/****************************************************************************************************
* Code of module wide FUNCTIONS
*****************************************************************************************************/

/*****************************************************************************************************/
/**
* brief    Inputs and Outputs Initialization to default values/configuration
* author   Antonio Rodriguez
* param    void
* return   void
*/
void vfnInputs_Outputs_Init(void)
{
  volatile unsigned long delay;		  

/**********************************************************************************/			
/***** This section configures ADC pins (PE0-3), not ADC_Init() is needed then ****/
/**********************************************************************************/			

	/******************************************************/	
/**** This section configures port F pins 
	PF3 to PF1 output (PF On board LEDs), PF4 (input SW1) PF0 (input SW2) ****/
/******************************************************/	
  SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOF; // activate port 
	delay = SYSCTL_RCGC2_R;						// allow time to finish activating
 	GPIO_PORTF_LOCK_R = 0x4C4F434B;  //the value 0x4C4F.434B unlocks the GPIO Commit (GPIOCR) register for write access.
	GPIO_PORTF_DIR_R = 0x0E;					// PF3 to PF1 output (PF On board LEDs), PF0 (input SW2)  
	GPIO_PORTF_CR_R = 0x1F;						// allow changes to PF4-0
  GPIO_PORTF_AFSEL_R &= ~0x1E;			//     disable alt funct on PF4; disable alt funct on PF3-1
	GPIO_PORTF_DEN_R |= 0x1F;					//     enable digital I/O on PF4;  enable digital I/O on PF3-1   
  GPIO_PORTF_PCTL_R &= ~0x000FFFFF;	// configure PF4 as GPIO; configure PF3-0 as GPIO
  GPIO_PORTF_AMSEL_R = 0x00;				//     disable analog functionality on PF
  GPIO_PORTF_PUR_R |= 0x11;					// enable weak pull-up on PF0 and PF4
	GPIO_PORTF_IS_R &= ~0x11;					//     PF4 and PF0 (SW2)is edge-sensitive
	GPIO_PORTF_IBE_R &= ~0x11;				//     PF4 and PF0 is not both edges
  GPIO_PORTF_IEV_R &= ~0x11;				//     PF4 and PF0 falling edge event
  GPIO_PORTF_ICR_R = 0x11;      		//  clear flags 0 and flags 4
  GPIO_PORTF_IM_R |= 0x11;      		//  arm interrupt on PF0 and PF4
//	NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00400000; // priority 2
//  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00A00000; // priority 5
//  NVIC_EN0_R = 0x40000000;      		// ) enable interrupt 30 in NVIC


	


/**************************************************************************************************************/			
/***** This section Initializes Nokia LCD pins in Port A. As a consequence, not Nokia5110_Init() is needed ****/
/**************************************************************************************************************/	

// Initialize Nokia 5110 48x84 LCD by sending the proper
// commands to the PCD8544 driver.  One new feature of the
// LM4F120 is that its SSIs can get their baud clock from
// either the system clock or from the 16 MHz precision
// internal oscillator.  If the system clock is faster than
// 50 MHz, the SSI baud clock will be faster than the 4 MHz
// maximum of the Nokia 5110.
// inputs: none
// outputs: none
// assumes: system clock rate of 50 MHz or less

  SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOA; // activates port A
    
//  delay = SYSCTL_RCGC2_R;               // allow time to finish activating
    
  /*Configuring port A pines*/
  GPIO_PORTA_DIR_R |= 0xC0;             // convierte PA6,7 en salidas
  GPIO_PORTA_AFSEL_R |= 0x2C;           // habilita funcion alterna de PA2,3,5, funcion de SSI lista para usarse
  GPIO_PORTA_AFSEL_R &= ~0xC0;          // deshabilita funcion alterna para PA6,7
  GPIO_PORTA_DEN_R |= 0xEC;             // habilita I/O digital en PA2,3,5,6,7
                                          // configure PA2,3,5 as SSI
  GPIO_PORTA_PCTL_R = (GPIO_PORTA_PCTL_R&0xFF0F00FF)+0x00202200;
                                          // configure PA6,7 as GPIO
  GPIO_PORTA_PCTL_R = (GPIO_PORTA_PCTL_R&0x00FFFFFF)+0x00000000;
  GPIO_PORTA_AMSEL_R &= ~0xEC;          // deshabilita analog function en pines PA2,3,5,6,7 


/***********************************************************************************************/			
/***** This section Configures Port B to Motor control and Infra-red LED output  ***********/
/***********************************************************************************************/	


  SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOB; // activates port B
    
  delay = SYSCTL_RCGC2_R;               // allow time to finish activating
    
  //Configuring port B pins
  GPIO_PORTB_DIR_R |= 0xFF;             // convierte PB0-7 en salidas
  GPIO_PORTB_AFSEL_R &= ~0xFF;          // deshabilita funcion alterna para PB0-7
  GPIO_PORTB_DEN_R |= 0xFF;             // habilita I/O digital , now they can drive a logic value
  GPIO_PORTB_DR8R_R |= 0xFF;            // PB0-7 can drive up to 8mA out
                                        // configure PB0-7 as GPIO
  GPIO_PORTB_PCTL_R = (GPIO_PORTB_PCTL_R&0xFFFFFFFF)+0x00000000;
  GPIO_PORTB_AMSEL_R &= ~0xFF;          // deshabilita analog function en pines PB0-7 
   


/***********************************************************************************************/			
/***** Requiered configuration for Motor  ******************************************************/
/***********************************************************************************************/	

	GPIO_PORTB_DATA_R &= ~0x20;   						// make PB5 low
  NVIC_ST_CTRL_R = 0;           						// disable SysTick during setup
  NVIC_ST_RELOAD_R = FIFTYPERCENT_DC;       // reload value for 500us
  NVIC_ST_CURRENT_R = 0;        						// any write to current clears it
  NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R&0x00FFFFFF)|0x40000000; // priority 2
 

}
