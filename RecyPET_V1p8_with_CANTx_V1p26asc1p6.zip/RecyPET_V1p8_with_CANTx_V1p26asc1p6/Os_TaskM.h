/****************************************************************************************************/
/**
\file       Os_TaskM.h
\brief      Task Contro Block definition and FIFO info.
\author     Antonio Rodriguez Soto
\version    1.0
\date       01/03/2014
*/
/****************************************************************************************************/

#ifndef __OS_TASK_H        /*prevent duplicated includes*/ 
#define __OS_TASK_H 

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

#include   "Os_Types.h"
//#include   "SchM.h"

typedef struct 
	{
		tStackInformation StackInfo;      
		tSchedulerTasks_ID TaskId; 
		UINT32 priority;
		tTaskStates enTaskState;
		UINT32 ContextLevel; 
		tPtr_to_function       ptrTask; 
		tPtr_to_function			 ptrSchM_Ostick;
}tTaskInfo;

typedef struct 
{
		tTaskInfo      				 GenTaskInfo;
		UINT32								 PADA;
		UINT32								 PADB;
		UINT32								 PADC;
		UINT32								 PADD;
		UINT32								 PADE;
		UINT32								 PADF;
		UINT32								 PADG;
	  UINT32                 R4;
    UINT32                 R5;
    UINT32                 R6;
	  UINT32                 R7;	
    UINT32                 R8;
	  UINT32                 R9;
    UINT32                 R10;
    UINT32                 R11;
	  UINT32                 R0;	
    UINT32                 R1;
    UINT32                 R2;
		UINT32                 R3;
		UINT32                 R12;
		UINT32                 R14;		
  	tPtr_to_function       ptrTask_copy;  /*copy of ptrTask in tTaskInfo*/
		UINT32								 thumb_bit;
}tTaskControlBlock;



typedef struct 
 {
  UINT8 push_index;
  UINT8 pull_index;
  UINT8 data_count; 
  UINT8 buffer[FIFOSIZE];
 }tFIFO;
 

extern tFIFO priority_buffer[];

extern UINT8 RunningTaskIndex;    //should be set by dispatcher used by Terminate Task
extern UINT8 Task_Number;
extern tTaskControlBlock * ptr_task_ctrl_block;

//extern dword_int counter_RB;

/*****************************************************************************************************
* Definition of  VARIABLEs - 
*****************************************************************************************************/

extern tTaskControlBlock TimeTriggeredTasks[];



/*****************************************************************************************************
* Definition of  FUNCTIONS - 
*****************************************************************************************************/

void Os_Init(void);


StatusType ActivateTask( TaskType taskID );
StatusType TerminateTask( void );
StatusType GetTaskID(TaskRefType taskIDRef);


#endif    /*__OS_TASKCFG_H */


