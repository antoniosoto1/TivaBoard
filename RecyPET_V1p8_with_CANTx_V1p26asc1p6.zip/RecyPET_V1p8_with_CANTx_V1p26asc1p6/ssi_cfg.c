/****************************************************************************************************/
/**
\file       ssi_cfg.h
\brief      Synchronous Serial communication Interface functions
\author     Antonio Rodriguez
\version    1.0
\date       17/sep/2014
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

 #include    "ssi_cfg.h"
 
/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/

const tSSIchannel_config SSI_app_channel_config[]=
{ 
      SSI0_PORT,
			SSI0_BAUDRATE,	
			SSI0_MASTER,
			SSI0_CR0_SCR,
      SSI0_CR0_SPH,  
      SSI0_CR0_SPO,
			SSI0_CR0_DSS,
			SSI0_CR0_DSS_8,
      SSI0_CR0_FRF,
			SSI0_CR0_FRF_MOTO,
			SSI0_CC_CS_M,	
			SSI0_CC_CS_SYSPLL,
			SSI0_CPS_DVSR,
} ;   


const tSSIDriver_config SSI_app_Configuration= 
{
    sizeof (SSI_app_channel_config)/sizeof(SSI_app_channel_config[0]),  
    &SSI_app_channel_config[0]
 };

 