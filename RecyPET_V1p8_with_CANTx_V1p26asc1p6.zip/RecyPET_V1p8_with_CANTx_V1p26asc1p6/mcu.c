// Mcu.c
// Codigo probado en tarjetas tiva LM4F120/TM4C123
// definicion de APIs del Mcu
// Autor. Antonio Rodriguez
// Junio 1, 2014


#include "mcu.h"


/*************************************************************************************************************************
***	MCU_Init
*** Inicializacion del MCU
***	Para modificar este programa para que opere en otros microcontroladores, sera necesario cambiar la freq. del cristal y 
***	el divisor de reloj del sistema.
*** Autor. Antonio Rodriguez Soto
*************************************************************************************************************************/

// avisa al sistema que la freq del bus se deriva del PLL
void MCU_Init(void){
  // 0) Usar RCC2 provee mas opciones como configurar el PLL a 400 MHz
  SYSCTL_RCC2_R |= SYSCTL_RCC2_USERCC2;
  // 1) encender BYPASS2, indica que el system clock se derivara del OSC elegido y dividido por el valor especificado por SYSDIV2.
  SYSCTL_RCC2_R |= SYSCTL_RCC2_BYPASS2;
  // 2) elige OSC valor 
  SYSCTL_RCC_R &= ~SYSCTL_RCC_XTAL_M;   		// limpia campo XTAL 
  SYSCTL_RCC_R += SYSCTL_RCC_XTAL_16MHZ;		// configura cristal de 16 MHz
  SYSCTL_RCC2_R &= ~SYSCTL_RCC2_OSCSRC2_M;	// lo limpia para escritura
  SYSCTL_RCC2_R += SYSCTL_RCC2_OSCSRC2_MO;	// Main Osc sera el system clock
  // 3) PLL es activado limpiando PWRDN2
  SYSCTL_RCC2_R &= ~SYSCTL_RCC2_PWRDN2;
  //4)  configura y habilita el divisor del reloj usando SYSDIV2
  SYSCTL_RCC2_R |= SYSCTL_RCC2_DIV400;  				// configura el PLL a  400MHz 
  SYSCTL_RCC2_R = (SYSCTL_RCC2_R&~0x1FC00000) 	// limpia el campo del divisor del reloj
                  + (SYSDIV2<<22);      				// configura la freq del bus a 50MHz

 // 5) Espera a que PLLRIS cambie a alto, lo que indica que el PLL es estable
  while((SYSCTL_RIS_R&SYSCTL_RIS_PLLLRIS)==0){};
 // 6) Conecta al PLL limpiando el bit BYPASS2
  SYSCTL_RCC2_R &= ~SYSCTL_RCC2_BYPASS2;
}


