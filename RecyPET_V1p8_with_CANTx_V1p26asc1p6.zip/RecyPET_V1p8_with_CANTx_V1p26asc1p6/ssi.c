/****************************************************************************************************/
/**
\file       ssi.c
\brief      Synchronous Serial Communication Interface functions
\author     Antonio Rodriguez
\version    1.0
\date       17/Sept/2014
*/
/****************************************************************************************************/
 
/*****************************************************************************************************
* Include files
*****************************************************************************************************/

/** Own headers */
/* Periodic Interrupt Timer routines prototypes */
#include  "ssi.h"
#include  "ssi_prt.h"
#include  "ssi_cfg.h"
/** Variable types and common definitions */
#include  "typedefs.h"

tSSIchannel_config  * gptrSSIdriver_config;


/*Inicializa el PIT de acuerdo a la configuracion que se le pasa como parametro*/

void vfnSSI_Init(tSSIDriver_config *SSI_Dev_Conf)  
  {
    UINT8  u8NumOfChannels;
    tSSI_Channel ch;
		UINT32 ch_BR,ch_BitLen, ch_format,ch_ssi_frmt,ch_spi_frmt,ch_spi_dvsr; 									// baud rate del canal
	  tSSIchannel_config  *ptrSSI_Ch_Cnf; //Apuntador a la configuracion de los canales
		UINT8 ch_count;
    volatile unsigned long delay;
		
		u8NumOfChannels = SSI_Dev_Conf->u8Number_of_SSI_channels;
    if ((u8NumOfChannels)<1) return;  	//Verifica si hay canales a configurar

		//SSI_RCGC1_SSI0_SHIFT is temporally used, it works fine for SSI0 but nothing to do with SSI1/2/3
		//	delay = SYSCTL_RCGC2_R is required and that�s the reason why next line isn�t within for cycle

    SYSCTL_RCGC1_R |=  (1<<SSI_RCGC1_SSI0_SHIFT );         //0) Habilita el canal correspondiente  (pone la mascara) PERO APAGA LA SELECCION DE RCGCTIMER
 	
		
				// mueve el apuntador de la configuracion a uno local para facilitar la lectura del codigo	
		ptrSSI_Ch_Cnf = (tSSIchannel_config *)(SSI_Dev_Conf->ptr_SSIchannels_config); 
 	
		//Configura los canales de acuerdo a la configuracion 	
		for (ch_count=0;ch_count<u8NumOfChannels;ch_count++)
		{
			ch        =	(ptrSSI_Ch_Cnf+ch_count)->SSI_channel;
			ch_format =	(ptrSSI_Ch_Cnf+ch_count)->SSI_dss;
			ch_BR     =	(ptrSSI_Ch_Cnf+ch_count)->SSI_baudrate ;		// valor de baud rate por canal
			ch_BitLen = 	(ptrSSI_Ch_Cnf+ch_count)->SSI_bitlen;
			ch_ssi_frmt = (ptrSSI_Ch_Cnf+ch_count)->SSI_format;
			ch_spi_frmt = (ptrSSI_Ch_Cnf+ch_count)->SPI_format;
			ch_spi_dvsr =	(ptrSSI_Ch_Cnf+ch_count)->SSI_CPS_DVSR;
					
			SSI_SSICR1(ch_count)&= ~  SSI_CR1_SSE;           // deshabilita SSI
			
			// configuration starts here
			SSI_SSICR1(ch_count)&= ~ ptrSSI_Ch_Cnf-> SSI_ms ;            // master mode
																														
			// configuring for system PLL baud clk, selecting PIOSC as clk source
			SSI_SSICC(ch_count) = (SSI_SSICC(ch_count)&~((ptrSSI_Ch_Cnf+ch_count)->SSI_ClockCfg))+((ptrSSI_Ch_Cnf+ch_count)->SSI_ClockCfg_SYSPLL); 
			
			SSI_SSICR0(ch_count) &= ~ (	(ptrSSI_Ch_Cnf+ch_count)-> SSI_scr	|   // eg. ch_SCR = 0 (3.125 Mbps data rate)
																	(ptrSSI_Ch_Cnf+ch_count)-> SSI_sph  | 	// eg. ch_SPH = 0, captures data during 0 to 1 SSIclk edge . 
																	(ptrSSI_Ch_Cnf+ch_count)-> SSI_spo  );	// eg. ch_SPO = 0, SSIclk is forced LOW during idle periods 

			//Configure SCI parms
			vfnSSI_Configure(ch, ch_BR, ch_format, ch_BitLen, ch_format, ch_ssi_frmt, ch_spi_frmt, ch_spi_dvsr ); 	
				
			SSI_SSICR1(ch_count)|= SSI_CR1_SSE;           // enable SSI
											
			// configuartion ends here	
	}		
		
}
	
	// calcula el factor que se va a sumar al SSI CCPSR (50M/3.125M) = 16 en caso del SSI0
	#define SSI_syst_clk_dvdr	(system_clock/u32SSIBaudRate) 

void vfnSSI_Configure( UINT8  u8SSIPort, UINT32  u32SSIBaudRate, UINT32 u32ChFormat , UINT32 u32ChBL, UINT32 u32frmt, UINT32 u32ssi_frmt, UINT32 u32spi_frmt, UINT32 u32spi_ch_dvsr )
{
	
	// clock divider for 3.125 MHz SSIClk (50 MHz PIOSC/16)
  SSI_SSICPSR(u8SSIPort) = (SSI_SSICPSR(u8SSIPort)&~u32spi_ch_dvsr)+SSI_syst_clk_dvdr;

	// FRF = Freescale format, SSIFss pin is forced high during idle perios
	SSI_SSICR0(u8SSIPort) = (SSI_SSICR0(u8SSIPort)&~u32ssi_frmt) + u32spi_frmt;
	// DSS = 8-bit data
	SSI_SSICR0(u8SSIPort) = (SSI_SSICR0(u8SSIPort)&~u32ChFormat) + u32ChBL;
}
