/*
  timers register map pag 723 Table 11-12
  file: SSi_ptr.h
  Este archivo complementa las definiciones de perifericos del tm4c123gh6pm.h.
  Define estructuras y macros para acceso a registros a traves de apuntadores 
  lo que facilita la configuracion dinamica del SSiTx.
  Nota:  Estas definiciones estan basdas en la forma en que se manejan los header files en  ARM, por ejemplo MKL46Z4.h de Kinetis
*/


#ifndef __SSI_PRT_H__ 
#define __SSI_PRT_H__


#include "typedefs.h"
#include 	"inc/tm4c123gh6pm.h"

/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/


/** SSI - Peripheral register structure */
typedef struct  SSI_MemMap
{
  struct
  {
		UINT32    SSI_CR0;  	/*SSI Control 0*/	
		UINT32    SSI_CR1;  	/*SSI Control 1*/
		UINT32    SSI_DR;   	/*SSI Data*/
		UINT32    SSI_SR;   	/*SSI Status*/
		UINT32    SSI_CPSR; 	/*SSI Clock Prescale*/ 
		UINT32    SSI_IM;  		/*SSI Interrupt Mask*/	
		UINT32    SSI_RIS;  	/*SSI Raw Interrupt Status*/
		UINT32    SSI_MIS;   	/*SSI Masked Interrupt Status*/
		UINT32    SSI_ICR;   	/*SSI Interrupt Clear*/
		UINT32    SSI_DMACTL; /*SSI DMA Control*/
  }CHANNEL[3];  /* SSI channel[x]*/
}volatile * SSI_MemMapPtr;

/** SSI - Peripheral register structure */
typedef struct  SSI_CC_MemMap
{
  struct
  {
		UINT32    SSI_CC;  	/*SSI Control 0*/	
  }CHANNEL[3];  /* SSI channel[x]*/
}volatile * SSI_CC_MemMap_Ptr;



/* SSI - Register accessors */
#define SSI_SSICR0_REG(base,index)               ((base)->CHANNEL[index].SSI_CR0)
#define SSI_SSICR1_REG(base,index)               ((base)->CHANNEL[index].SSI_CR1)
#define SSI_SSIDR_REG(base,index)                ((base)->CHANNEL[index].SSI_DR)
#define SSI_SSISR_REG(base,index)                ((base)->CHANNEL[index].SSI_SR)
#define SSI_SSICPSR_REG(base,index)              ((base)->CHANNEL[index].SSI_CPSR)
#define SSI_SSIIM_REG(base,index)                ((base)->CHANNEL[index].SSI_IM)
#define SSI_SSIRIS_REG(base,index)               ((base)->CHANNEL[index].SSI_RIS)
#define SSI_SSIMIS_REG(base,index)               ((base)->CHANNEL[index].SSI_MIS)
#define SSI_SSIICR_REG(base,index)               ((base)->CHANNEL[index].SSI_ICR)
#define SSI_SSIDMACTL_REG(base,index)            ((base)->CHANNEL[index].SSI_DMACTL)
#define SSI_SSICC_REG(base,index)            		 ((base)->CHANNEL[index].SSI_CC)


/* ----------------------------------------------------------------------------
   -- SSI Register Masks
   ---------------------------------------------------------------------------- */
/*Estas mascaras estan ya definidas en el header del micro                      */

/* SSI - Peripheral instance base addresses */
/** Peripheral SSI base pointer */
#define SSI_BASE_PTR            ((SSI_MemMapPtr) 0x40008000)
#define SSI_BASE_PTR_2          ((SSI_CC_MemMap_Ptr) 0x40008FC8)



/* SSI - Register array accessors */
#define SSI_SSICR0(index) 			SSI_SSICR0_REG(SSI_BASE_PTR,index)                 
#define SSI_SSICR1(index)				SSI_SSICR1_REG(SSI_BASE_PTR,index) 
#define SSI_SSIDR(index)       	SSI_SSIDR_REG(SSI_BASE_PTR,index)
#define SSI_SSISR(index)		  	SSI_SSISR_REG(SSI_BASE_PTR,index)                
#define SSI_SSICPSR(index)      SSI_SSICPSR_REG(SSI_BASE_PTR,index)
#define SSI_SSIIM(index)			  SSI_SSIIMR_REG(SSI_BASE_PTR,index)                 
#define SSI_SSIRIS(index)  			SSI_SSIRIS_REG(SSI_BASE_PTR,index)
#define SSI_SSIMIS(index)    		SSI_SSIMIS_REG(SSI_BASE_PTR,index
#define SSI_SSIICR(index)			  SSI_SSIICR_REG(SSI_BASE_PTR,index)                
#define SSI_SSIDMACTL(index)		SSI_SSIDMACTL_REG(SSI_BASE_PTR,index)         
#define SSI_SSICC(index)    		SSI_SSICC_REG(SSI_BASE_PTR_2,index)  

#endif // __SSI_PRT_H__ 
