 /***************************************************************************************************/
/**
* \brief    Os_Task - Provides Task Manager services
* \author   Antonio Rodriguez Soto
* \services ActivateTask, TerminateTask, GetTaskID, GetTaskState
* \return   StatisType
* \todo     
*/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

 
 #include    "Os_Types.h"
 #include    "Os_TaskM.h"
 #include    "Os_TaskCfg.h"
  #include   "can0.h"
 #include    "heap.h"


/*****************************************************************************************************
* Definition of module wide VARIABLEs 
*****************************************************************************************************/

tTaskControlBlock * ptr_task_ctrl_block;

tFIFO priority_buffer[PRIORITY_NUMBER];

UINT8 RunningTaskIndex;    //should be set by dispatcher used by Terminate Task

UINT8 Task_Number;
tPtr_to_function PortF_handler;

 /****************************************************************************************************/
/**
* \brief    Scheduler - Initialization
* \author   Antonio Rodriguez Soto
* \param    void
* \return   void
* \todo     
*/
		 UINT32 Stacktempo;
void Os_Init(void)//SchM_TaskConfigType *SchM_Config)   
{
     UINT8 u8Index, Ptr_TaskAdd = 0x0C, Ptr_TaskCntxtlvl1=0x08;

     tTaskControlBlock * ptr_task;
     tTaskControlBlock * ptr_task_end;
		
     const tSchM_Task_Descriptor * ptr_Sch_task_descriptor;
		 UINT32	sizeTCB, sizeTCB_TskNum;
     const tTask_config * ptr_task_cnfg;
     
     ptr_task_cnfg= &Task_config[0];
          
    Task_Number = ptr_task_cnfg->u8Number_of_tasks;
	
    ptr_Sch_task_descriptor= ptr_task_cnfg->ptr_task_config;   // este apuntador apunta a las tareaas de SCHM_cfg.c
     
    /* Periodic Interrupt Timer Low Level Initialization */
    Gpt_Init(&GPT_Driver_config[0]);
	
		sizeTCB = sizeof(tTaskControlBlock);
		sizeTCB_TskNum = (Task_Number * sizeTCB);
    
        /* Allocate memory for internal status and control structures */
    ptr_task_ctrl_block =  (tTaskControlBlock *) Heap_Malloc( sizeTCB_TskNum);
    		
    ptr_task=  ptr_task_ctrl_block;
    
    for(u8Index=0;u8Index<Task_Number;u8Index++)
    {
			/*Relative addressing to store Stack allocations*/
			Stacktempo= (UINT32 )ptr_task+  sizeTCB - Ptr_TaskAdd; /// to be able to find end of stack pointer
			ptr_task_end =(tTaskControlBlock *) Stacktempo;
			Stacktempo= (UINT32 ) ptr_task + Ptr_TaskCntxtlvl1;
			
			ptr_task->GenTaskInfo.StackInfo.Stack_Start = (UINT32 *) (ptr_task);
			ptr_task->GenTaskInfo.StackInfo.Stack_End 	= (UINT32 *)ptr_task_end;
			ptr_task->GenTaskInfo.StackInfo.Stack_CntxLvl1 = (UINT32 *)Stacktempo; /*Redundant value to store stack allocation after Timer 0 isr */
			ptr_task->GenTaskInfo.TaskId 				= ptr_Sch_task_descriptor->task_ID ;
			ptr_task->GenTaskInfo.priority 			= ptr_Sch_task_descriptor->Priority  ;
			ptr_task->GenTaskInfo.enTaskState 	= SUSPENDED ; 
      ptr_task->GenTaskInfo.ContextLevel	=	0;
			ptr_task->GenTaskInfo.ptrTask 			= ptr_Sch_task_descriptor->Sch_Callback;
			/*It's an event triggered task <<Button Handler>> will return to intermediate GPIOPortF_HandlerUser for activation*/	
			if (u8Index==(Button_Task1_ID)) 
			{
				ptr_task->GenTaskInfo.ptrSchM_Ostick = &GPIOPortF_HandlerUser; /*En ensamblador, el handler debera apuntar a esta direccion de funcion y retornar a modo thread para atenderla*/
				PortF_handler=&GPIOPortF_HandlerUser;
			}
			else	/*It's a periodic task systick handler will return to Ostick for activation*/
			{
				
				ptr_task->GenTaskInfo.ptrSchM_Ostick = &SchM_OsTick;
			}
				ptr_task->PADA= 0xFAFAFAFA;
			ptr_task->PADB= 0xFBFBFBFB;
			ptr_task->PADC= 0xFCFCFCFC;
			ptr_task->PADD= 0xFDFDFDFD;
			ptr_task->PADE= 0xFEFEFEFE;
			ptr_task->PADF= 0xFFFFFFFF;
			ptr_task->PADG= 0xEEEEEEEE;
			ptr_task->R4  = 0x04040404; 
			ptr_task->R5	= 0x05050505; 
			ptr_task->R6	= 0x06060606; 
			ptr_task->R7	= 0x07070707; 
			ptr_task->R8  = 0x08080808; 
			ptr_task->R9  = 0x09090909; 
			ptr_task->R10	= 0xAAAAAAAA; 
			ptr_task->R11	= 0xBBBBBBBB; 
			ptr_task->R0	= 0x00000000; 
			ptr_task->R1  = 0x01010101; 
			ptr_task->R2  = 0x02020202;
			ptr_task->R3  = 0x03030303;			
			ptr_task->R12  = 0x12121212;
			ptr_task->R14  = 0x14141414;
			ptr_task->ptrTask_copy= ptr_Sch_task_descriptor->Sch_Callback;    
			ptr_task->thumb_bit = 0x01000000;		// thumb bit   		

      ptr_task++;
      ptr_Sch_task_descriptor++;
     }
		
}


/*************

Mete la tarea en el buffer de activacion correspondiente a su prioridad

         data_count++
*********************/

StatusType push_task(UINT8 priority, UINT8 task_index)
 { 
 

    if (priority_buffer[priority].data_count<FIFOSIZE && priority< PRIORITY_NUMBER)
     {    
      priority_buffer[priority].buffer[priority_buffer[priority].push_index]= task_index;
      priority_buffer[priority].data_count++;
      if (++priority_buffer[priority].push_index>=FIFOSIZE) priority_buffer[priority].push_index=0;
      return E_OK;
     } 
     else 
     {
      return   E_OS_LIMIT;
     }
 }


/*
 Saca la tarea del buffer de activacion
 dimuniye el la cuentta de la fifo     data_count--
*/

StatusType pull_task(UINT8 priority, UINT8 *task_index)
 {
   if (priority_buffer[priority].data_count>0)
     {    
      *task_index = priority_buffer[priority].buffer[ priority_buffer[priority].pull_index];
      priority_buffer[priority].data_count--;
       if (++priority_buffer[priority].pull_index>=FIFOSIZE) priority_buffer[priority].pull_index=0;
      return E_OK;
     }
    else 
     {
      return   E_OS_LIMIT;
     }
    
 }


/***************************************************************************************************/
/**
* \brief    Mete la tarea con TaskID al buffer para ser activada
* \author   Antonio Rodriguez Soto
* \param    TaskType taskID)
* \return   StatusType
* \todo     
*/
StatusType ActivateTask( TaskType taskID )
{ 

   UINT8 i=0;
   StatusType error;
   tTaskControlBlock * ptr_task; 
	
   ptr_task = ptr_task_ctrl_block;
    
   /*search for task*/        
   while( i<Task_Number &&  ptr_task->GenTaskInfo.TaskId !=taskID) 
   {
     ptr_task++;
     i++;
   }
   
  if (i<Task_Number  && ptr_task->GenTaskInfo.TaskId ==taskID) //es una tarea valida
     {
       ptr_task->GenTaskInfo.enTaskState= READY;
       error = push_task(ptr_task->GenTaskInfo.priority,i);   //mete la tarea en la cola de ejecucion de acuerdo con su prioridad 
       return  E_OK;
     }
 else 
    {
      return E_OS_ID;
    } 
}



/***************************************************************************************************/
/**
* \brief    This API service moves the task identified by the input
            taskID from the SUSPENDED state to the READY state if
            no error occurred, and put the task into the priority buffer
            queue tail.
* \author   Antonio Rodriguez Soto
* \param    TaskType taskID)
* \return   StatusType
* \todo     
*/


StatusType TerminateTask(void)
{ 

  
//   UINT16 i=0;
   UINT8 last_task;
   StatusType error;
   tTaskControlBlock * ptr_task;
  
     
   ptr_task = ptr_task_ctrl_block+RunningTaskIndex;
   ptr_task->GenTaskInfo.enTaskState= SUSPENDED;
   error = pull_task(ptr_task->GenTaskInfo.priority,&last_task);   //Saca la tarea en ejecucion


   if (last_task == RunningTaskIndex) 
   {
     // Dispatcher();
      RunningTaskIndex =0;
      return  E_OK;
   } 
   else 
   {
     RunningTaskIndex =0;
     return E_OS_ID;
   }
}





/***************************************************************************************************/
/**
* \brief    This service provides the application with the identifier of the
            task that is presently running. It is intended to be used in hook
            routines and library functions to check the task from which it
            was invoked.
* \author   Antonio Rodriguez Soto
* \param    void
* \return   StatusType
* \todo     
*/

StatusType GetTaskID(TaskRefType taskIDRef)
{ 

   tTaskControlBlock * ptr_task;  
   ptr_task = ptr_task_ctrl_block+RunningTaskIndex;
   *taskIDRef =  ptr_task->GenTaskInfo.TaskId;
   return E_OK;
   
}

