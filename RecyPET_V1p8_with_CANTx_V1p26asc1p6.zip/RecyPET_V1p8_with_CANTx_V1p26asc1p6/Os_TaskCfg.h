                 /****************************************************************************************************/
/**
\file       Os_TaskCfg.h
\brief      TADL. Task Descriptor, contains info structures about triggered and cyclic schedulled task
						scheduller stablishes temporal control structure of all tasks apriori.
\author     Antonio Soto
\version    1.0
\date       03/07/2014
*/
/****************************************************************************************************/


#ifndef __OS_TASKCFG_H        /*prevent duplicated includes*/ 
#define __OS_TASKCFG_H 



/** Core modules */
/**  Configuration Options */
#include     "Mcu_Cfg.h"
#include    "Os_Task.h"

/** Variable types and common definitions */
#include    "typedefs.h"
/** Scheduler function prototypes definitions */
#include    "SchM.h"


#define PRIORITY_NUMBER  12

/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/

typedef struct
{
  UINT8                     task_ID;
  UINT8                     task_type;
  UINT8                     Priority;
  UINT8                     Task_Mask;        /*Mask of task*/
  UINT8                     Task_Offset;      /*Offset of task*/
  UINT16                    StackSize;
  UINT16                    RelativeDeadline;
  tCallbackFunction         Sch_Callback;   	/*Task Callback*/
} tSchM_Task_Descriptor;											/*configuracion de las tareas*/
 


/* tTask_config
  estructura padre de la configuracion
  Define cuantas tareas se van a usar y
  que valor van a tener los 2 microtimers
*/
typedef struct 
{
   UINT8 u8Number_of_tasks;    //Number of tasks channels
   const tSchM_Task_Descriptor *ptr_task_config;   //* apuntador a la configuracion de las tareas
}tTask_config;


extern const   tSchM_Task_Descriptor  SchM_Config []; // allocates TADL in flash

extern  const tTask_config  Task_config[];

void Task_sch_activate(const tTask_config  * pTask_Config);



#endif    /*__OS_TASKCFG_H */

