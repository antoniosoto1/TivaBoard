/****************************************************************************************************/
/*
file       Gpt_Cfg.h
brief      General Purpose Timer Config (GPT), Supports PIT reqs. 
						Allows the user to configure GPT driver
						
author    
date       1/jun/2014
*/
/****************************************************************************************************/


#ifndef __GPT_CFG_H__        /*previene doble inclusion*/
#define __GPT_CFG_H__

/*****************************************************************************************************
* Include files
*****************************************************************************************************/


#include     "Mcu_Cfg.h"
#include     "typedefs.h"

/*****************************************************************************************************
* Declaration of project wide TYPES
*****************************************************************************************************/
// frecuencia del bus 400MHz/(SYSDIV2+1) = 400MHz/(4+1) = 80 MHz
// periodo = 1/80M = 12.5ns 

//#define TIC_OS_PERIOD 40000 			// periodo(80MHz)*TIC_OS_PERIOD = 12.5ns*40000 = 500us

//#define TIC_OS_PERIOD 25000 			// periodo(50MHz)*TIC_OS_PERIOD = 20ns*25000 = 500us
	#define TIC_OS_PERIOD 1000000 			// periodo(50MHz)*TIC_OS_PERIOD = 20ns*1,000,000 = 20ms

#define Interrupt_num0 19
/*
 Enumera "Define" los canales disponibles en el PIT  0 a 7 
*/

typedef enum 
{
    PIT_CH_Tim0A  = 0,
    PIT_CH_Tim1A  = 1,
    PIT_CH_Tim2A  = 2,
    PIT_CH_Tim3A  = 3,
    PIT_CH_Tim4A  = 4,
    PIT_CH_Tim5A  = 5,
}tPIT_Channel;  

/* tPITchannel_config
     Define el canal a utilizar del PIT  0 - 7
     Tiempo de Load del pit channel
*/
typedef struct 
{
   tPIT_Channel      	pit_channel;    /*Que canal se va a utilizar de 0 a 7*/
   UINT32				  	 	timerPeriod;	  /*Tiempo del timer en ticx */
	 UINT8							interrupt_number;
	 tCallbackFunction	PIT_callback;   /*CallBack */
}tPITchannel_config;


/* tPITDevice_config
  estructura padre de la configuracion
  Define cuantos canales del PIT se van a usar y
*/
typedef struct 
{
   UINT8 u8Number_of_PIT_channels;   //Number of PIT channels
   const tPITchannel_config *ptr_PITchannels_config;   //* apuntador a la configuracion de los canales
}tPITDevice_config;

/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/

typedef struct 
{
   UINT8  Channels;
	
}tTIMDevice_config;


// Estructura para la configuracion de todos los timers
typedef struct 
{
    	const tPITDevice_config   * ptr_PITDevice_config;
      const tTIMDevice_config   * ptr_TIMDevice_config;
}Gpt_Device_ConfigType;


/* Estructura para la configuracion del driver de GPT */
typedef struct
  {
    UINT8 NumberOfGPTDevices;        /*indica cuantos Devices van a habilitarse p. ej. 1 PIT, 2 TIM*/
    const Gpt_Device_ConfigType    * ptr_Gpt_Device_Config;  
  }Gpt_ConfigType;
  


extern const Gpt_ConfigType GPT_Driver_config[];


# endif // __GPT_CFG_H__
