/****************************************************************************************************/
/*
file       ssu_cfg.h
brief      synchronous serial interface (SSI), Supports SSI reqs. 
					 Allows the user to configure SSI driver
						
author    
date       15/sep/2014
*/
/****************************************************************************************************/


#ifndef __SSI_CFG_H__        /*previene doble inclusion*/
#define __SSI_CFG_H__


/*-- Channel 0 conf values --------------------------------------------*/

#define SSI0_BAUDRATE  				(3125000) // Hz
#define SSI0_MASTER    				0x00000004
#define SSI0_PORT      				(0)

/*-- Communication status defines -------------------------------------*/
#define SSI0_CR0_SCR        0x0000FF00  // SSI Serial Clock Rate	
#define SSI0_CR0_SPH   			0x00000080  // SSI Serial Clock Phase
#define SSI0_CR0_SPO   			0x00000040  // SSI Serial Clock Polarity
#define SSI0_CR0_DSS        0x0000000F  // SSI Data Size 
#define SSI0_CR0_DSS_8      0x00000007  // 8-bit datos
#define SSI0_CR0_FRF				0x00000030  // SSI Frame Format Select
#define SSI0_CR0_FRF_MOTO		0x00000000  // SSI Frame Format Select

	
#define SSI0_CC_CS_M   		 	0x0000000F  // SSI Baud Clock Source
#define SSI0_CC_CS_SYSPLL 	0x00000000  // The system clock (if the
                                          // PLL bypass is in effect) or the
                                          // PLL output (default)										
#define	SSI0_CPS_DVSR				0x000000FF	// SSI Clock Prescale Divisor											

/*--  Enable ----------------------------------------------------------*/
#define SSI_CR1_SSE         0x00000002 	// SSI Sync Serial Port

// system clock 50MHz check SYSDIV2 =  on mcu_cfg.h
#define system_clock						(50000000)																						


/*****************************************************************************************************
* Include files
*****************************************************************************************************/

#include     "typedefs.h"

/*
 Enumera "Define" los canales disponibles en el SSI  0 - 3 
*/

typedef enum 
{
    SSI_CH0  = 0,
    SSI_CH1  = 1,
    SSI_CH2  = 2,
    SSI_CH3  = 3,
}tSSI_Channel;  

/* tPITchannel_config
     Define el canal a utilizar del SSI  0 - 3
     Tiempo de Load del pit channel
*/
typedef struct 
{
  tSSI_Channel      SSI_channel;    			/*Que canal se va a utilizar de SSI  0 - 3*/
	UINT32				  	SSI_baudrate;	  			/*SSI Baud Rate */
	UINT32						SSI_ms;								/*0 -> SSI as master, 1 -> SSI as slv*/
	UINT32						SSI_scr;							/*SSI serial clock rate*/
	UINT32						SSI_sph;							/*Captures in 0 to 1 SSIclk edge*/
	UINT32						SSI_spo;							/*SSIclk is forced LOW during idle periods*/
	UINT32						SSI_dss;							/*Lenght of data frameF*/
	UINT32						SSI_bitlen;						/*bits numer 7*/
	UINT32						SSI_format;			  		/*Choose one among three SPI frame type*/
	UINT32 						SPI_format;
	UINT32						SSI_ClockCfg;					/*selects the source that generates for the SSI BR*/
	UINT32						SSI_ClockCfg_SYSPLL;
	UINT32						SSI_CPS_DVSR;      		/*SSI Clock Prescale Divisor*/
 }tSSIchannel_config;


/* tSSIDevice_config
  estructura padre de la configuracion
  Define cuantos canales del SSI se van a usar y
*/
typedef struct 
{
   UINT8 u8Number_of_SSI_channels;   //Number of SSI channels
   const tSSIchannel_config *ptr_SSIchannels_config;   //* apuntador a la configuracion de los canales
}tSSIDriver_config;

extern const tSSIDriver_config SSI_app_Configuration  ;

# endif // __SSI_CFG_H__
