// mcu_cfg.h
// Permite al usuario llevar a cabo la configuracion del PLL
// settings a configurar: 1) frecuencia del XTAL , 2) la frequencia del bus
// Autor. Antonio Rodriguez Soto
// Junio 1, 2014


#ifndef __MCU_CFG_H__        /*previene doble inclusion*/
#define __MCU_CFG_H__

// 1) Definiendo frequencia del XTAL

#define SYSCTL_RIS_PLLLRIS      0x00000040  // Estado interrupcion del PLL , indica que se ha enganchado y esta lista 
#define SYSCTL_RCC_XTAL_M       0x000007C0  // (1111100b)
#define SYSCTL_RCC_XTAL_16MHZ   0x00000540  // Cristal de 16 MHz esta conectado (10101000000b)

#define SYSCTL_RCC2_USERCC2     0x80000000  // Use RCC2 divisor
#define SYSCTL_RCC2_DIV400      0x40000000  // Divide PLL de 400 MHz a 200MHz                                         
#define SYSCTL_RCC2_SYSDIV2_M   0x1F800000  // System Clock Divisor 2
#define SYSCTL_RCC2_SYSDIV2LSB  0x00400000  // Additional LSB for SYSDIV2
#define SYSCTL_RCC2_PWRDN2      0x00002000  // Power-Down PLL 2
#define SYSCTL_RCC2_BYPASS2     0x00000800  // PLL Bypass 2
#define SYSCTL_RCC2_OSCSRC2_M   0x00000070  // Oscillator Source 2
#define SYSCTL_RCC2_OSCSRC2_MO  0x00000000  // MOSC

// 2) Inicializa SYSDIV2 al PLL con frecuencia deseada

#define SYSDIV2 7
// frecuencia del bus 400/(SYSDIV2+1)MHz= 400/(7+1)MHz = 50 MHz

#endif //  __MCU_CFG_H__ 

