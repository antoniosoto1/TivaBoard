/**
file       main.c
brief      Generacion de TICK para OS Tarea 1
author     Team4    Antonio Soto, Jaime Paz, Luis Puebla
version    1.0
date       12/feb/2014
*/
/****************************************************************************************************/


#include  "main.h"
#include "mcu_cfg.h"
#include "mcu.h"
#include "Gpt.h"
#include "io.h"
#include "Os_TaskM.h"
#include "heap.h"
#include "Nokia_dsp.h"
#include "Nokia_test.h"
#include "TExaS.h"


/******************************************************************************************************
* Code of module wide FUNCTIONS
******************************************************************************************************/

UINT16 status; 
UINT16 Distance; 


void delay_time(unsigned long halfsecs){
  unsigned long count;
  
  while(halfsecs > 0 ) { // repeat while there are still halfsecs to delay
    count = 770000/*1538460*/; // 400000*0.5/0.13 that it takes 0.13 sec to count down to zero
    while (count > 0) { 
      count--;
    } // This while loop takes approximately 3 cycles
    halfsecs--;
  }
}
volatile unsigned long FallingEdges = 0; // incremented after button press

/*Version Thread del GPIOPortF_Handler. Sin esta funcion el micro no soltaria el modo handler */
void GPIOPortF_HandlerUser(void)	{
	
	GPIO_PORTF_ICR_R = 0x10;      // acknowledge flag4
  FallingEdges = FallingEdges + 1;
	ActivateTask(Button_Task1_ID);
	//Nokia5110_Clear();
	Dispatcher();
	
	restore_context();	
}





	void ADC0_Init(void)
{
	  volatile unsigned long delay;	
	SYSCTL_RCGC2_R |= 0x00000010;   // 1) activates clock for Port E
  delay = SYSCTL_RCGC2_R;         //    allow time for clock to stabilize
  GPIO_PORTE_DIR_R &= ~0x0F;      // 2) makes PE0-PE3 input
  GPIO_PORTE_AFSEL_R |= 0x0F;     // 3) enable Alternate Funct on PE0-3
  GPIO_PORTE_DEN_R &= ~0x08;      // 4) analog input set, disables digital I/O on PE0-3
  GPIO_PORTE_AMSEL_R |= 0x0F;     // 5) enable analog function on PE0-3
  SYSCTL_RCGC0_R |= 0x00010000;   // 6) activates ADC0, Each bit in RCG0 controls a clock enable for a given interfa
  delay = SYSCTL_RCGC2_R;     
	delay = SYSCTL_RCGC2_R;     		// extra time to stabilize
  SYSCTL_RCGC0_R &= ~0x00000300;  // 7) max samplling rate = 125K sapmle/s
  ADC0_SSPRI_R = 0x0123;          // 8) Sequencer 3 is highest priority
  ADC0_ACTSS_R &= ~0x0008;        // 9) disable sample sequencer 3
  ADC0_EMUX_R &= ~0xF000;         // 10) seq3 is software trigger
 	ADC0_SSCTL3_R = 0x0006;         // 12) no TS0 D0, yes IE0 END0
  ADC0_ACTSS_R |= 0x0008;         // 13) enable sample sequencer 3 
	ADC0_SAC_R = 0X06	;							// 64x hardware oversampling applied to conversion results.	

}

/*~~~~~~~ Main Code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

int main(void) {

	TExaS_Init(ADC0_AIN1_PIN_PE2, SSI0_Real_Nokia5110_Scope);		// 1) Activate TExaS_Init 
		status = Heap_Init();
//	DisableInterrupts();
  ADC0_Init();
	/*Initializes MCU ports*/
	vfnInputs_Outputs_Init();    
	/*Initializes SPI port
	Has to be called before MCU init, otherwise,
	RCGCTIMER_R TIMER0 SELECTOR is cleared */
	vfnSync_Serial_Init(); 	

		/* Bus runs at 50MHz at 08.25.2017 ; PLL initialization to the desired target frequency */  
	MCU_Init(); /* vfnPLL_Init(); */
	
	
	/* Periodic Interrupt Timer Low Level Initialization */
	// se llama en OS_Init de Os_taskM.c Gpt_Init(&GPT_Driver_config[0]);

	    /*Initialize the OS*/
  Os_Init();




	Nokia5110_Init();
  
    /* Start execution of task scheduler */
    SchM_Start();
    EnableInterrupts();

  while(1){
    WaitForInterrupt();
  }
}
