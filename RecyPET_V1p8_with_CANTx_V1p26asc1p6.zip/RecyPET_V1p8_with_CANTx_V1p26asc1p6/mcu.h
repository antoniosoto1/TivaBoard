// mcu.h
// Exporta cualquier API requerdia por los clientes del MCU
// Autor. Antonio Rodriguez Soto
// Junio 1, 2014
#ifndef __MCU_H__ 
#define __MCU_H__

#include "mcu_cfg.h"
#include "inc/tm4c123gh6pm.h"

// indica al sistema que obtenga su reloj del PLL
void MCU_Init(void);


#endif  // __MCU_H__
